﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio05LinqBasico
{
    public class Persona
    {
        public string nombre { get; set; }
        public DateTime fechaNacimiento { get; set; }
        public double sueldo { get; set; }

    }

}
